<script src="js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript">
    $(window).on('load', function() {
      setTimeout(function() {
        $('#popupModal').modal();
      },10000);
    });
</script>